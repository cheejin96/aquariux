INSERT INTO Clients (id, name, wallet) VALUES (1, 'cj', 50000.00);

INSERT INTO Stocks (id, name, valuePerStock) VALUES (1, 'Ethereum - ETHUSDT', 1639.39);
INSERT INTO Stocks (id, name, valuePerStock) VALUES (1, 'Bitcoin - BTCUSDT', 25815.67);